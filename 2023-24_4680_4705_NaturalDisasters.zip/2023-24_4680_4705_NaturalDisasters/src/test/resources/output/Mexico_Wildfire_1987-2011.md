**Mexico_Wildfire**

*Mexico-Wildfire-1987-2011*

| Year | Value |
|------|-------|
| 1987 | 0 |
| 1988 | 0 |
| 1989 | 1 |
| 1990 | 0 |
| 1991 | 0 |
| 1992 | 0 |
| 1993 | 0 |
| 1994 | 0 |
| 1995 | 0 |
| 1996 | 0 |
| 1997 | 0 |
| 1998 | 1 |
| 1999 | 0 |
| 2000 | 0 |
| 2001 | 0 |
| 2002 | 0 |
| 2003 | 1 |
| 2004 | 0 |
| 2005 | 0 |
| 2006 | 0 |
| 2007 | 0 |
| 2008 | 0 |
| 2009 | 0 |
| 2010 | 0 |
| 2011 | 1 |


**Descriptive Stats:**  Descriptive Stats:
 Mean: 0.16
 Standard Deviation: 0.37416573867739406
 Min: 0.0
 Max: 1.0
 Kurtosis: 2.060982495765108
 gMean: 0.0
 Count: 25
 Median: 0.0
 Sum: 4.0

**Regression Results:**  Regression Analysis:
 Intercept: -7.5284615384615305
 Slope: 0.003846153846153842
 Slope Error: 0.010570308056074274
 Trend: Tendency Stable

