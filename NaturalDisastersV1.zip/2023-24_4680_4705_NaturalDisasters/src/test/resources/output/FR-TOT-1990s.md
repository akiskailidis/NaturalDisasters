**FR-TOT-1990s**

_Country ~ France Indicator: TOTAL_

|*Year*|*Value*|
|----|----|
|1990 |10|
|1991 |3|
|1992 |3|
|1993 |3|
|1994 |3|
|1995 |1|
|1996 |3|
|1997 |3|
|1998 |2|
|1999 |8|

DescriptiveStatsResult [count=10, min=1, gMean=3.211328629325388, mean=3.9, median=3, max=10, kurtosis=1.8322952329608597, stdev=2.8067379246694513, sum=39]

RegressionResult [intercept=330.27272727272725, slope=-0.16363636363636364, slopeError=0.32260988048450395, Decreased Tendency]

